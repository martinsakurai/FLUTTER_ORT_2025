import 'package:flutter/material.dart';


void main() {
  runApp(const MainApp());
}


class MainApp extends StatefulWidget {
  const MainApp({super.key});


  @override
  State<MainApp> createState() => _MainAppState();
}


class _MainAppState extends State<MainApp> {
  TextEditingController inputUsuario = TextEditingController();
  TextEditingController inputContrasena = TextEditingController();
  String comprobacion = '';
  bool mostrarContrasena = false; // ✅ Ahora está dentro del State
  String mensaje = ""; // Mensaje que se va a mostrar en el Snackbar
  Color colorFondo = Colors.green; // Color del fondo del Snackbar


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center( // Centra vertical y horizontalmente el contenido
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("Bienvenido a MECA-LOGIN"),
              const SizedBox(height: 20),
              Text(comprobacion),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: TextField(
                  controller: inputUsuario,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Introduzca su nombre de usuario',
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: TextField(
                  obscureText: !mostrarContrasena, // si es true, se esconde la contraseña, es para decir si se quiere mostrar con puntitos o no
                  controller: inputContrasena,
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    labelText: 'Introduzca su contraseña',
                    suffixIcon: IconButton( // suffixicon es una propiedad del inputDecoration que permite poner el icono de un ojo al final del textifeld
                      icon: Icon( // aca estamos usando un "iconbutton", por lo que el icono puede ser presionado
                        mostrarContrasena // condición: si mostrar contraseña es...
                            ? Icons.visibility // SI MOSTRARCONTRASEÑA ES TRUE: aparece un ojo abierto
                            : Icons.visibility_off, // SI ES FALSE: aparece un ojo cerrado
                      ),
                      onPressed: () { // COMO ES UN BOTÓN, SE PONE EL ONPRESSED. INVIERTE EL ESTADO DE LA CONTRASEÑA. CUANDO SE LO PRESIONA
                        setState(() {
                          mostrarContrasena = !mostrarContrasena; // SE INVIERTE EL VALOR DE MOSTRARCONTRASEÑA
                        });
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Builder( 
                builder: (context) => ElevatedButton( 
                  onPressed: () {
                    
                    if (inputUsuario.text.isEmpty || inputContrasena.text.isEmpty) {
                      mensaje = "⚠️ COMPLETE TODOS LOS CAMPOS";
                      colorFondo = Colors.orange;
                    } 
                    else if (inputUsuario.text == "martinsakurai" &&
                        inputContrasena.text == "MarSaku07") {
                      mensaje = "✅ INGRESO CORRECTO";
                      colorFondo = Colors.green;
                    } else {
                      mensaje = "❌ USUARIO O CONTRASEÑA INCORRECTOS";
                      colorFondo = Colors.red;
                    }


                    // MOSTRAMOS EL SNACKBAR CON MENSAJE TEMPORAL
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(mensaje),
                        backgroundColor: colorFondo,
                        duration: const Duration(seconds: 4), // el cartel desaparece después de 4 segundos
                      ),
                    );
                  },
                  child: const Text('Ingresar'),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
